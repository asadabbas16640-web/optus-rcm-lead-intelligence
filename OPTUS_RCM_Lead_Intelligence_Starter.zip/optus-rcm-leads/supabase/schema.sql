-- OPTUS RCM Leads: private per-user CRM. Run once in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.leads (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
 npi text, name text not null, practice text not null default '', city text not null default '', state text not null check(state in ('NM','TX')),
 specialty text not null default '', phone text not null default '', email text not null default '', website text not null default '',
 score integer not null default 50 check(score between 0 and 100),
 stage text not null default 'New' check(stage in ('New','Qualified','Contacted','Meeting','Proposal','Won','Not Interested')),
 verification_status text not null default 'Unverified' check(verification_status in ('Unverified','Needs Review','Verified')),
 source_url text not null default '', verified_at timestamptz, notes text not null default '', followup_on date,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 constraint npi_valid check(npi is null or npi ~ '^[0-9]{10}$'), unique(owner_id,npi)
);
create table if not exists public.lead_sources (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
 lead_id uuid not null references public.leads(id) on delete cascade, url text not null, evidence text not null default '', checked_at timestamptz not null default now()
);
create table if not exists public.activities (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
 lead_id uuid not null references public.leads(id) on delete cascade, kind text not null check(kind in ('Call','Email','Meeting','Note','Follow-up')),
 details text not null default '', due_on date, completed_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.import_batches (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
 state text not null check(state in ('NM','TX')), specialty text not null default '', imported integer not null default 0, skipped integer not null default 0,
 created_at timestamptz not null default now()
);
create index if not exists leads_owner_state_idx on public.leads(owner_id,state);
create index if not exists leads_owner_followup_idx on public.leads(owner_id,followup_on);
create index if not exists activities_owner_due_idx on public.activities(owner_id,due_on);
create index if not exists sources_lead_idx on public.lead_sources(lead_id);
create or replace function public.owns_lead(p_lead_id uuid) returns boolean language sql stable security definer set search_path = '' as $$
 select exists(select 1 from public.leads where id=p_lead_id and owner_id=(select auth.uid()));
$$;
revoke all on function public.owns_lead(uuid) from public;
grant execute on function public.owns_lead(uuid) to authenticated;
create or replace function public.set_updated_at() returns trigger language plpgsql set search_path = '' as $$begin new.updated_at=now(); return new; end$$;
drop trigger if exists leads_updated_at on public.leads;
create trigger leads_updated_at before update on public.leads for each row execute function public.set_updated_at();
-- Grants and RLS are BOTH required.
revoke all on public.leads,public.lead_sources,public.activities,public.import_batches from anon,authenticated;
grant select,insert,update,delete on public.leads,public.lead_sources,public.activities,public.import_batches to authenticated;
alter table public.leads enable row level security;
alter table public.lead_sources enable row level security;
alter table public.activities enable row level security;
alter table public.import_batches enable row level security;
-- Per-user isolation for top-level records.
do $$ declare t text; begin
 foreach t in array array['leads','import_batches'] loop
 execute format('drop policy if exists owner_select on public.%I',t);
 execute format('drop policy if exists owner_insert on public.%I',t);
 execute format('drop policy if exists owner_update on public.%I',t);
 execute format('drop policy if exists owner_delete on public.%I',t);
 execute format('create policy owner_select on public.%I for select to authenticated using (owner_id=(select auth.uid()))',t);
 execute format('create policy owner_insert on public.%I for insert to authenticated with check (owner_id=(select auth.uid()))',t);
 execute format('create policy owner_update on public.%I for update to authenticated using (owner_id=(select auth.uid())) with check (owner_id=(select auth.uid()))',t);
 execute format('create policy owner_delete on public.%I for delete to authenticated using (owner_id=(select auth.uid()))',t);
 end loop; end $$;
-- Child rows must belong to the user AND point to their own lead.
do $$ declare t text; begin
 foreach t in array array['lead_sources','activities'] loop
 execute format('drop policy if exists owner_select on public.%I',t);
 execute format('drop policy if exists owner_insert on public.%I',t);
 execute format('drop policy if exists owner_update on public.%I',t);
 execute format('drop policy if exists owner_delete on public.%I',t);
 execute format('create policy owner_select on public.%I for select to authenticated using (owner_id=(select auth.uid()) and public.owns_lead(lead_id))',t);
 execute format('create policy owner_insert on public.%I for insert to authenticated with check (owner_id=(select auth.uid()) and public.owns_lead(lead_id))',t);
 execute format('create policy owner_update on public.%I for update to authenticated using (owner_id=(select auth.uid()) and public.owns_lead(lead_id)) with check (owner_id=(select auth.uid()) and public.owns_lead(lead_id))',t);
 execute format('create policy owner_delete on public.%I for delete to authenticated using (owner_id=(select auth.uid()) and public.owns_lead(lead_id))',t);
 end loop; end $$;
