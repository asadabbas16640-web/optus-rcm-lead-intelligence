# OPTUS RCM Lead Intelligence — MVP

React + Vite + Supabase + Cloudflare Pages. No real patients or PHI should be entered. No demo leads are preloaded.

## 1. Supabase
1. Create a Supabase project. In SQL Editor, run `supabase/schema.sql` once.
2. Under Authentication > Providers > Email, enable email/password login. Disable public sign-ups in Authentication settings (allow only invited accounts).
3. In Authentication > Users, invite your own email. Set the Site URL and Redirect URLs to your deployed Cloudflare Pages URL. Complete the email invitation.
4. In Project Settings / Connect, copy the Project URL and **publishable** key (not secret or service-role key).

## 2. GitHub
Create a **private** repository, upload these project files, and do not upload `.env.local` or passwords.

## 3. Cloudflare Pages
Create a Pages project, connect the GitHub repository. Choose framework preset Vite, build command `npm run build`, output directory `dist`.
In Pages > Settings > Environment variables (production and preview), add:
- `VITE_SUPABASE_URL` = your Supabase Project URL
- `VITE_SUPABASE_PUBLISHABLE_KEY` = your Supabase publishable key
Deploy and use the generated `*.pages.dev` URL. If you add a custom domain, update Supabase Auth Site URL and redirect allow-list.

## 4. Security checks before use
- Open in private browsing: no leads visible without login.
- Invite two test users and verify each cannot see, edit, delete, or reference the other's leads.
- Check RLS is enabled on all four public tables; verify anon has no table grants.
- Verify child records cannot point to another user's lead.
- Do not store patient records, PHI, credentials, or private personal information in this prospecting CRM.
- Mark contacts Verified only after checking official public sources and recording evidence.
- Review Supabase RLS and grant policies with `supabase test db` before production rollout.

## 5. NPI Import notes
The in-browser lookup queries CMS NPI Registry API v2.1 and imports individual previewed results; it may fail if the API blocks cross-origin requests. For production, add a rate-limited Cloudflare Worker server-side proxy and pagination. Imports are deduplicated by `(owner_id,npi)` and do not overwrite existing records. A provider NPI does not establish independent ownership or buying intent.

## 6. Limitations
- User account invitations are administered in Supabase, not the app.
- No scheduled reminders or automated verification; follow-up dates are displayed in-app.
- No server-side import jobs or bulk imports yet.
- User-managed verification labels are not proof of actual source verification.
- Export is CSV of filtered records; keep exported files secure.
- The free-tier deployment and Supabase SQL have not been run against your accounts.
